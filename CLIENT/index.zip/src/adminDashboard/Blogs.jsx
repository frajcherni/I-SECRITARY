import React from 'react'

function Blogs() {
  return (
    <div>Blogs</div>
  )
}

export default Blogs